from flask import Flask, request, jsonify
import time
import random

app = Flask(__name__)

def interpolation_search(arr, target):
    """
    Interpolation Search Algorithm
    Time Complexity: O(log log n) average, O(n) worst case
    Space Complexity: O(1)
    """
    low, high = 0, len(arr) - 1
    comparisons = 0

    while low <= high and arr[low] <= target <= arr[high]:
        comparisons += 1
        if low == high:
            if arr[low] == target:
                return low, comparisons
            return -1, comparisons

        # Interpolation formula
        pos = low + int(((target - arr[low]) * (high - low))
                        / (arr[high] - arr[low]))

        if arr[pos] == target:
            return pos, comparisons
        elif arr[pos] < target:
            low = pos + 1
        else:
            high = pos - 1

    return -1, comparisons

def binary_search(arr, target):
    """Binary Search for comparison"""
    low, high = 0, len(arr) - 1
    comparisons = 0
    while low <= high:
        comparisons += 1
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid, comparisons
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1, comparisons

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Interpolation Search Algorithm Visualizer</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            
            .container {
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                max-width: 900px;
                width: 100%;
                padding: 40px;
            }
            
            h1 {
                text-align: center;
                color: #333;
                margin-bottom: 10px;
                font-size: 2.5em;
            }
            
            .subtitle {
                text-align: center;
                color: #666;
                margin-bottom: 40px;
                font-size: 1.1em;
            }
            
            .search-section {
                background: #f8f9fa;
                padding: 30px;
                border-radius: 15px;
                margin-bottom: 30px;
            }
            
            .input-group {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .form-group {
                display: flex;
                flex-direction: column;
            }
            
            label {
                font-weight: 600;
                margin-bottom: 8px;
                color: #333;
            }
            
            input[type="number"], input[type="text"] {
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 1em;
                transition: all 0.3s;
            }
            
            input[type="number"]:focus, input[type="text"]:focus {
                outline: none;
                border-color: #667eea;
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            }
            
            .button-group {
                display: flex;
                gap: 10px;
                justify-content: center;
            }
            
            button {
                padding: 12px 30px;
                border: none;
                border-radius: 8px;
                font-size: 1em;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
            }
            
            .btn-search {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                flex: 1;
            }
            
            .btn-search:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
            }
            
            .btn-clear {
                background: #e0e0e0;
                color: #333;
                flex: 1;
            }
            
            .btn-clear:hover {
                background: #d0d0d0;
            }
            
            .results-section {
                display: none;
                margin-top: 30px;
            }
            
            .results-section.show {
                display: block;
            }
            
            .result-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px;
                border-radius: 12px;
                margin-bottom: 20px;
            }
            
            .result-item {
                display: flex;
                justify-content: space-between;
                margin-bottom: 10px;
            }
            
            .result-item:last-child {
                margin-bottom: 0;
            }
            
            .result-label {
                font-weight: 600;
            }
            
            .result-value {
                font-size: 1.1em;
                font-weight: bold;
            }
            
            .performance-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            
            .performance-table th {
                background: #667eea;
                color: white;
                padding: 12px;
                text-align: left;
                font-weight: 600;
            }
            
            .performance-table td {
                padding: 12px;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .performance-table tr:hover {
                background: #f8f9fa;
            }
            
            .status {
                padding: 15px;
                border-radius: 8px;
                margin-top: 20px;
                display: none;
            }
            
            .status.show {
                display: block;
            }
            
            .status.success {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            
            .status.error {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }
            
            .status.loading {
                background: #d1ecf1;
                color: #0c5460;
                border: 1px solid #bee5eb;
            }
            
            @media (max-width: 600px) {
                .input-group {
                    grid-template-columns: 1fr;
                }
                
                h1 {
                    font-size: 1.8em;
                }
                
                .container {
                    padding: 20px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔍 Interpolation Search</h1>
            <p class="subtitle">Advanced Search Algorithm Visualizer</p>
            
            <div class="search-section">
                <div class="input-group">
                    <div class="form-group">
                        <label for="arraySize">Array Size:</label>
                        <input type="number" id="arraySize" value="10000" min="100" max="100000" step="100">
                    </div>
                    <div class="form-group">
                        <label for="searchValue">Search Value:</label>
                        <input type="number" id="searchValue" placeholder="Enter number to search">
                    </div>
                </div>
                
                <div class="button-group">
                    <button class="btn-search" onclick="performSearch()">Search</button>
                    <button class="btn-clear" onclick="clearResults()">Clear</button>
                </div>
            </div>
            
            <div id="status" class="status"></div>
            
            <div id="resultsSection" class="results-section">
                <div class="result-card" id="resultCard"></div>
                
                <h2 style="color: #333; margin-top: 30px; margin-bottom: 15px;">⚡ Performance Analysis</h2>
                <table class="performance-table" id="performanceTable">
                    <thead>
                        <tr>
                            <th>Array Size</th>
                            <th>IS Time (ms)</th>
                            <th>BS Time (ms)</th>
                            <th>IS Comparisons</th>
                            <th>BS Comparisons</th>
                            <th>Efficiency</th>
                        </tr>
                    </thead>
                    <tbody id="performanceBody"></tbody>
                </table>
            </div>
        </div>
        
        <script>
            function showStatus(message, type) {
                const status = document.getElementById('status');
                status.textContent = message;
                status.className = `status show ${type}`;
            }
            
            function clearResults() {
                document.getElementById('resultsSection').classList.remove('show');
                document.getElementById('status').classList.remove('show');
                document.getElementById('searchValue').value = '';
            }
            
            async function performSearch() {
                const arraySize = parseInt(document.getElementById('arraySize').value);
                const searchValue = parseInt(document.getElementById('searchValue').value);
                
                if (!searchValue && searchValue !== 0) {
                    showStatus('❌ Please enter a search value', 'error');
                    return;
                }
                
                showStatus('⏳ Searching...', 'loading');
                
                try {
                    const response = await fetch('/api/search', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            array_size: arraySize,
                            search_value: searchValue
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (!response.ok) {
                        showStatus(`❌ ${data.error}`, 'error');
                        return;
                    }
                    
                    displayResults(data);
                    showStatus('✅ Search completed successfully!', 'success');
                } catch (error) {
                    showStatus(`❌ Error: ${error.message}`, 'error');
                }
            }
            
            function displayResults(data) {
                const resultCard = document.getElementById('resultCard');
                const found = data.result.index !== -1;
                const statusText = found ? '✅ Found' : '❌ Not Found';
                
                resultCard.innerHTML = `
                    <div class="result-item">
                        <span class="result-label">Status:</span>
                        <span class="result-value">${statusText}</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Index:</span>
                        <span class="result-value">${found ? data.result.index : 'N/A'}</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Comparisons (Interpolation Search):</span>
                        <span class="result-value">${data.result.interpolation_comparisons}</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Comparisons (Binary Search):</span>
                        <span class="result-value">${data.result.binary_comparisons}</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Time (Interpolation Search):</span>
                        <span class="result-value">${data.result.is_time.toFixed(4)} ms</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Time (Binary Search):</span>
                        <span class="result-value">${data.result.bs_time.toFixed(4)} ms</span>
                    </div>
                `;
                
                const tbody = document.getElementById('performanceBody');
                tbody.innerHTML = data.performance.map(row => `
                    <tr>
                        <td>${row.size}</td>
                        <td>${row.is_time.toFixed(4)}</td>
                        <td>${row.bs_time.toFixed(4)}</td>
                        <td>${row.is_comparisons}</td>
                        <td>${row.bs_comparisons}</td>
                        <td>${row.efficiency}%</td>
                    </tr>
                `).join('');
                
                document.getElementById('resultsSection').classList.add('show');
            }
        </script>
    </body>
    </html>
    '''

@app.route('/api/search', methods=['POST'])
def search():
    try:
        data = request.json
        array_size = data.get('array_size', 10000)
        search_value = data.get('search_value')
        
        if search_value is None:
            return jsonify({'error': 'Search value is required'}), 400
        
        if array_size < 100 or array_size > 100000:
            return jsonify({'error': 'Array size must be between 100 and 100000'}), 400
        
        # Generate sorted array
        arr = sorted(random.sample(range(array_size * 10), array_size))
        
        # Perform searches
        start = time.perf_counter()
        idx_is, comp_is = interpolation_search(arr, search_value)
        is_time = (time.perf_counter() - start) * 1000
        
        start = time.perf_counter()
        idx_bs, comp_bs = binary_search(arr, search_value)
        bs_time = (time.perf_counter() - start) * 1000
        
        # Performance analysis
        sizes = [1000, 5000, 10000, 50000, 100000]
        performance = []
        
        for size in sizes:
            test_arr = sorted(random.sample(range(size * 10), size))
            target = test_arr[random.randint(0, size - 1)]
            
            # Time interpolation search
            start = time.perf_counter()
            for _ in range(100):
                interpolation_search(test_arr, target)
            is_avg_time = (time.perf_counter() - start) / 100 * 1000
            
            # Time binary search
            start = time.perf_counter()
            for _ in range(100):
                binary_search(test_arr, target)
            bs_avg_time = (time.perf_counter() - start) / 100 * 1000
            
            # Get comparisons
            _, is_comps = interpolation_search(test_arr, target)
            _, bs_comps = binary_search(test_arr, target)
            
            efficiency = round((bs_avg_time - is_avg_time) / bs_avg_time * 100, 2)
            
            performance.append({
                'size': size,
                'is_time': is_avg_time,
                'bs_time': bs_avg_time,
                'is_comparisons': is_comps,
                'bs_comparisons': bs_comps,
                'efficiency': efficiency
            })
        
        return jsonify({
            'result': {
                'index': idx_is,
                'interpolation_comparisons': comp_is,
                'binary_comparisons': comp_bs,
                'is_time': is_time,
                'bs_time': bs_time
            },
            'performance': performance
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
