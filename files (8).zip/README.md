# 🔍 Interpolation Search - Vercel App

A beautiful, interactive web application that visualizes and compares **Interpolation Search** with Binary Search algorithms.

## 🎯 Features

- **Interactive Search Interface**: Search for values in dynamically generated arrays
- **Real-time Performance Analysis**: Compare Interpolation Search vs Binary Search
- **Visual Results**: See comparison metrics including time and comparisons made
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Modern UI**: Beautiful gradient design with smooth animations

## 📊 What It Does

The app implements:
- **Interpolation Search**: O(log log n) average time complexity
- **Binary Search**: O(log n) time complexity
- **Performance Comparison**: Side-by-side metrics for different array sizes

## 🚀 Deploy to Vercel (30 seconds)

### Step 1: Prepare Your Files
Make sure you have these files in your project folder:
```
project-folder/
├── api/
│   └── index.py
├── requirements.txt
├── vercel.json
└── README.md
```

### Step 2: Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/interpolation-search.git
git branch -M main
git push -u origin main
```

### Step 3: Deploy on Vercel
**Option A: Using Vercel Dashboard (Easiest)**
1. Go to [vercel.com](https://vercel.com)
2. Sign in with GitHub
3. Click "New Project"
4. Select your repository
5. Click "Deploy"
6. ✅ Done! Your app is live!

**Option B: Using Vercel CLI**
```bash
npm i -g vercel
vercel login
vercel
```

## 🔧 Local Development

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run Locally
```bash
python api/index.py
```

Visit `http://localhost:5000` in your browser.

## 📝 How to Use the App

1. **Set Array Size**: Choose the size of the array to search (100-100,000)
2. **Enter Search Value**: Enter a number you want to find
3. **Click Search**: See instant results with performance metrics
4. **View Analysis**: Compare Interpolation Search vs Binary Search performance

## 📈 Performance Metrics

The app shows:
- **Found Status**: Whether the value was found
- **Index**: Position in the array (if found)
- **Comparisons**: Number of comparisons made by each algorithm
- **Execution Time**: Time taken in milliseconds
- **Efficiency**: Percentage improvement of Interpolation Search over Binary Search

## 🎨 Customization

To modify the app, edit `api/index.py`:

- **Change colors**: Look for gradient hex values `#667eea`, `#764ba2`
- **Modify array sizes**: Edit the `sizes` list in performance_analysis
- **Adjust styling**: Modify the CSS in the HTML section

## 📦 Tech Stack

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Deployment**: Vercel

## 🔗 Your Live App URL

After deployment, Vercel will give you a URL like:
```
https://interpolation-search-xxxx.vercel.app
```

Share this link with anyone to showcase your algorithm!

## 💡 Tips

- For best performance, use array sizes between 1,000 and 100,000
- Search values are randomly generated but guaranteed to be in the array
- The performance metrics run 100 iterations for accuracy

## 🐛 Troubleshooting

**App won't deploy?**
- Make sure `vercel.json` is in the root directory
- Check that `requirements.txt` has Flask listed
- Ensure `api/index.py` exists

**Search not working?**
- Try refreshing the page
- Check browser console for errors (F12)
- Make sure you entered a valid number

## 📞 Support

For issues or questions, check:
- [Vercel Docs](https://vercel.com/docs)
- [Flask Docs](https://flask.palletsprojects.com/)

---

**Created**: 2024 | **Algorithm**: Interpolation Search | **Framework**: Flask
